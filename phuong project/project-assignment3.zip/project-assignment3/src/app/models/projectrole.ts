export class projectrole {

      constructor(
        public id: number,
        public name :string
      ) { }

    }
