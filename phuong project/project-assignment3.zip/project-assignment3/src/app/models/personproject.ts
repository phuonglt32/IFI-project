export class personproject {

  constructor(
    public id: {
      idPersonal: number,
      idProjectRole: number
    },
    public projectNam: string
  ) { }

}
